<?php
namespace qnap;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'not here' );
}

class QNAP_Export_Abstract {}
class QNAP_Import_Abstract {}
class QNAP_Config {}
