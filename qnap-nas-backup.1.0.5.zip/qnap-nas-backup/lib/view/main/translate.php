<?php
namespace qnap;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'not here' );
}
?>

<a href="https://translate.wordpress.org/projects/wp-plugins/qnap-wp-migration/" target="_blank"><?php _e( 'Translate', QNAP_PLUGIN_NAME ); ?></a>
