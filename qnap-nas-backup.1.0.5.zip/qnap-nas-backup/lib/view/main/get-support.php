<?php
namespace qnap;

if ( ! defined( 'ABSPATH' ) ) {
	die( 'not here' );
}
?>

<a href="https://qeek.com/help" target="_blank"><?php _e( 'Get Support', QNAP_PLUGIN_NAME ); ?></a>
